# Original data

Place the unmodified public version 3 `measures_v2.csv` here, or set `PMSM_CSV_PATH` to the supplied original attachment. `scripts/fetch_data.py` can attempt retrieval from the depositor when no local file exists. See `docs/DATA_DICTIONARY.md` for provenance, units, expected schema and exact hash.

The data are not bundled. The dataset depositor’s CC BY-SA 4.0 terms are separate from the source-code licence. Preserve source attribution and inspect those terms for any dataset redistribution. No personal Google Drive session is required.
